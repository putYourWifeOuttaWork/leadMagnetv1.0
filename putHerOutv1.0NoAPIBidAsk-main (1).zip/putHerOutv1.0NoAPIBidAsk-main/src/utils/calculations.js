// Constants
const TAX_RATE = 0.25; // 25% tax rate
const HARE_RESERVE_RATE = 0.15; // 15% reserve for hare strategy
const MONTHLY_PREMIUM_RATE = 0.0725; // 7.25% monthly premium

export const calculateLotRequirement = (stockPrice) => {
  return stockPrice * 100; // Cost for 100 shares
};

export const calculateContracts = (capital, lotRequirement, strategy) => {
  // Hare can use twice the leverage
  const multiplier = strategy === 'aggressive' ? 2 : 1;
  return Math.floor((capital / lotRequirement) * multiplier);
};

export const calculateMonthlyIncome = (contracts, stockPrice) => {
  const lotValue = stockPrice * 100;
  const grossIncome = lotValue * MONTHLY_PREMIUM_RATE * contracts;
  return grossIncome;
};

export const calculateNetIncome = (grossIncome, strategy) => {
  const afterTax = grossIncome * (1 - TAX_RATE);
  if (strategy === 'aggressive') {
    // For hare strategy, set aside 20% reserve
    return afterTax * (1 - HARE_RESERVE_RATE);
  }
  return afterTax;
};

export const calculateReserve = (grossIncome, strategy) => {
  const afterTax = grossIncome * (1 - TAX_RATE);
  if (strategy === 'aggressive') {
    return afterTax * HARE_RESERVE_RATE;
  }
  return 0;
};

export const calculateProjection = (inputs, stockPrices) => {
  const stockPrice = stockPrices[inputs.selectedStock];
  const lotRequirement = calculateLotRequirement(stockPrice);
  let currentCapital = parseFloat(inputs.capital);
  const monthlyInvestment = parseFloat(inputs.monthlyInvestment) || 0;
  let projData = [];
  const targetMonthlyIncome = parseFloat(inputs.wifeIncome);
  
  // Always calculate full 36 months
  for (let months = 0; months <= 36; months++) {
    // Calculate number of contracts possible with current capital
    const possibleContracts = calculateContracts(currentCapital, lotRequirement, inputs.strategy);
    
    // Calculate gross and net income
    const grossMonthlyIncome = calculateMonthlyIncome(possibleContracts, stockPrice);
    const netMonthlyIncome = calculateNetIncome(grossMonthlyIncome, inputs.strategy);
    const monthlyReserve = calculateReserve(grossMonthlyIncome, inputs.strategy);

    projData.push({
      month: months,
      capital: Math.floor(currentCapital * 100) / 100,
      contracts: possibleContracts,
      grossMonthlyIncome: Math.floor(grossMonthlyIncome * 100) / 100,
      netMonthlyIncome: Math.floor(netMonthlyIncome * 100) / 100,
      monthlyReserve: Math.floor(monthlyReserve * 100) / 100,
      freedomProgress: Math.floor((netMonthlyIncome / targetMonthlyIncome) * 100 * 100) / 100,
      nextContractAt: Math.floor((possibleContracts + 1) * lotRequirement * 100) / 100,
      totalInvested: Math.floor((parseFloat(inputs.capital) + (monthlyInvestment * months)) * 100) / 100,
      stockPrice: stockPrice
    });
    
    // Add monthly investment, net income, and reserve to capital
    currentCapital += monthlyInvestment + netMonthlyIncome + monthlyReserve;
  }
  
  const freedomMonth = projData.findIndex(d => d.netMonthlyIncome >= targetMonthlyIncome);
  
  const timeline = {
    months: freedomMonth > -1 ? freedomMonth : 36,
    finalCapital: Math.floor(projData[projData.length - 1].capital * 100) / 100,
    monthlyIncome: Math.floor(projData[projData.length - 1].netMonthlyIncome * 100) / 100,
    totalContracts: projData[projData.length - 1].contracts,
    totalInvested: Math.floor(projData[projData.length - 1].totalInvested * 100) / 100
  };
  
  return { timeline, projectionData: projData };
};
