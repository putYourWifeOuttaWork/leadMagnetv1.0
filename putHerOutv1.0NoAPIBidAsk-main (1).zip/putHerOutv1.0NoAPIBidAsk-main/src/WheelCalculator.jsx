import React, { useState, useEffect } from 'react';
import { fetchStockPrices } from './services/StockPriceService';
import StepsNavigation from './components/StepsNavigation';
import ResultsVisualization from './components/ResultsVisualization';
import SlideOutTracker from './components/SlideOutTracker';
import { ChevronUp } from 'lucide-react';
import IncomeStep from './components/steps/IncomeStep';
import StrategyStep from './components/steps/StrategyStep';
import CapitalStep from './components/steps/CapitalStep';
import StockStep from './components/steps/StockStep';
import { calculateProjection, calculateLotRequirement } from './utils/calculations';

const WheelCalculator = () => {
  const [currentStep, setCurrentStep] = useState(1);
  const [visitedSteps, setVisitedSteps] = useState([1]);
  const [showTracker, setShowTracker] = useState(false);
  const [inputs, setInputs] = useState({
    wifeIncome: '',
    strategy: '',
    capital: '',
    monthlyInvestment: '',
    selectedStock: ''
  });
  const [stockPrices, setStockPrices] = useState({});
  const [timeline, setTimeline] = useState(null);
  const [projectionData, setProjectionData] = useState([]);

  useEffect(() => {
    const loadStockPrices = async () => {
      const prices = await fetchStockPrices();
      setStockPrices(prices);
    };
    loadStockPrices();
  }, []);

  const canProceed = (step) => {
    switch (step) {
      case 1:
        return !!inputs.wifeIncome;
      case 2:
        return !!inputs.strategy;
      case 3:
        return !!inputs.capital;
      case 4: {
        const lotRequirement = calculateLotRequirement(stockPrices[inputs.selectedStock]);
        const multiplier = inputs.strategy === 'aggressive' ? 2 : 1;
        const minimumRequired = lotRequirement / multiplier;
        return parseFloat(inputs.capital) >= minimumRequired;
      }
      default:
        return true;
    }
  };

  const handleStepChange = (newStep) => {
    if (canProceed(currentStep) || newStep < currentStep) {
      setCurrentStep(newStep);
      if (!visitedSteps.includes(newStep)) {
        setVisitedSteps([...visitedSteps, newStep]);
      }
    }
  };

  const handleCalculate = () => {
    if (!canProceed(4)) return;
    
    const { timeline: newTimeline, projectionData: newProjectionData } = calculateProjection(inputs, stockPrices);
    setTimeline(newTimeline);
    setProjectionData(newProjectionData);
    
    // Scroll to results
    const resultsElement = document.getElementById('results-section');
    if (resultsElement) {
      resultsElement.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="relative px-4 md:px-8">
      <StepsNavigation 
        currentStep={currentStep} 
        setStep={handleStepChange}
        visitedSteps={visitedSteps}
        canProceed={canProceed}
      />
      
      <div className="bg-white p-8 rounded-lg shadow-lg mb-12">
        <div className="space-y-8">
          {currentStep === 1 && (
            <IncomeStep
              value={inputs.wifeIncome}
              onChange={(value) => setInputs(prev => ({ ...prev, wifeIncome: value }))}
            />
          )}

          {currentStep === 2 && (
            <StrategyStep
              strategy={inputs.strategy}
              onChange={(value) => setInputs(prev => ({ ...prev, strategy: value }))}
            />
          )}

          {currentStep === 3 && (
            <CapitalStep
              capital={inputs.capital}
              monthlyInvestment={inputs.monthlyInvestment}
              onChange={(field, value) => setInputs(prev => ({ ...prev, [field]: value }))}
            />
          )}

          {currentStep === 4 && (
            <StockStep
              selectedStock={inputs.selectedStock}
              stockPrices={stockPrices}
              strategy={inputs.strategy}
              capital={inputs.capital}
              onChange={(value) => {
                setInputs(prev => ({ ...prev, selectedStock: value }));
                if (canProceed(4)) {
                  handleCalculate();
                }
              }}
            />
          )}

          <div className="flex justify-between mt-8">
            {currentStep > 1 && (
              <button
                onClick={() => handleStepChange(currentStep - 1)}
                className="px-8 py-3 bg-gray-100 rounded-lg hover:bg-gray-200"
              >
                Back
              </button>
            )}
            {currentStep < 4 ? (
              <button
                onClick={() => canProceed(currentStep) && handleStepChange(currentStep + 1)}
                className={`px-8 py-3 rounded-lg ml-auto ${
                  canProceed(currentStep)
                    ? 'bg-indigo-600 text-white hover:bg-indigo-700'
                    : 'bg-gray-200 cursor-not-allowed'
                }`}
              >
                {currentStep === 1 ? 'Start' : 'Next'}
              </button>
            ) : (
              <button
                onClick={handleCalculate}
                disabled={!canProceed(4)}
                className={`px-8 py-3 rounded-lg ml-auto ${
                  canProceed(4)
                    ? 'bg-indigo-600 text-white hover:bg-indigo-700'
                    : 'bg-gray-200 cursor-not-allowed'
                }`}
              >
                Calculate
              </button>
            )}
          </div>
        </div>
      </div>

      {projectionData.length > 0 && (
        <div id="results-section">
          <ResultsVisualization
            projectionData={projectionData}
            timeline={timeline}
            inputs={inputs}
          />
        </div>
      )}

      <SlideOutTracker
        showTracker={showTracker}
        setShowTracker={setShowTracker}
        steps={[
          {
            label: "Wife's Income",
            value: inputs.wifeIncome ? `$${Number(inputs.wifeIncome).toLocaleString()}/month` : null,
            complete: !!inputs.wifeIncome
          },
          {
            label: 'Strategy',
            value: inputs.strategy,
            complete: !!inputs.strategy
          },
          {
            label: 'Starting Capital',
            value: inputs.capital ? `$${Number(inputs.capital).toLocaleString()}` : null,
            complete: !!inputs.capital
          },
          {
            label: 'Stock Selection',
            value: inputs.selectedStock,
            complete: !!inputs.selectedStock && canProceed(4)
          }
        ]}
        currentStep={currentStep}
        timeline={timeline}
        projectionData={projectionData}
        inputs={inputs}
      />
    </div>
  );
};

export default WheelCalculator;
