import React from 'react';
import { Printer } from 'lucide-react';
import { format, addMonths } from 'date-fns';

export const WorkTogether = ({ projectionData, compact = false }) => {
  const handlePrint = () => {
    window.print();
  };

  const startDate = new Date();
  
  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center print:hidden">
        <h3 className={`${compact ? 'text-base' : 'text-xl'} font-bold text-gray-800`}>
          Freedom Journey Tracker
        </h3>
        {!compact && (
          <button
            onClick={handlePrint}
            className="flex items-center space-x-2 text-indigo-600 hover:text-indigo-700"
          >
            <Printer className="w-4 h-4" />
            <span>Print Tracker</span>
          </button>
        )}
      </div>

      <div className="print-section overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b">
              <th className="text-left py-1 print:text-[10px]">Date</th>
              <th className="text-right py-1 print:text-[10px]">Target</th>
              <th className="text-right py-1 print:text-[10px]">Actual</th>
              <th className="text-center py-1 print:text-[10px]">Contracts</th>
              <th className="text-right py-1 print:text-[10px]">Progress</th>
            </tr>
          </thead>
          <tbody className="text-sm">
            {projectionData.map((month, index) => {
              const date = addMonths(startDate, index);
              const prevMonth = index > 0 ? projectionData[index - 1] : null;
              const newContract = prevMonth && month.contracts > prevMonth.contracts;
              
              return (
                <tr 
                  key={index}
                  className={`border-b ${newContract ? 'bg-green-50' : ''}`}
                >
                  <td className="py-1 print:text-[10px] print:py-0">
                    {format(date, 'MMM yyyy')}
                    {newContract && !compact && (
                      <span className="ml-1 text-green-600 text-xs print:py-0">
                        🎯
                      </span>
                    )}
                  </td>
                  <td className="text-right py-1 print:text-[10px] print:py-0">
                    ${(month.netMonthlyIncome || 0).toLocaleString()}
                  </td>
                  <td className="text-right py-1 print:text-[10px] print:py-0">
                    <div className="print:hidden">
                      <input 
                        type="text"
                        className="w-full text-right border-b border-dashed border-gray-300 bg-transparent"
                        placeholder="$___"
                      />
                    </div>
                    <div className="hidden print:block">$_____</div>
                  </td>
                  <td className="text-center py-1 print:text-[10px] print:py-0">
                    {month.contracts}
                  </td>
                  <td className="text-right py-1 print:text-[10px] print:py-0">
                    {Math.floor(month.freedomProgress)}%
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default WorkTogether;
