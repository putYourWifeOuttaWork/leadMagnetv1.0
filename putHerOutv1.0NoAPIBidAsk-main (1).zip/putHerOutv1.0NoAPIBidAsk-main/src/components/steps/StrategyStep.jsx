import React from 'react';

const StrategyStep = ({ strategy, onChange }) => {
  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-center text-gray-800 mb-8">
        Choose Your Path to Freedom
      </h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <button
          onClick={() => onChange('conservative')}
          className={`p-6 rounded-xl border-2 transition-all ${
            strategy === 'conservative'
              ? 'border-blue-600 bg-blue-50 shadow-lg scale-105'
              : 'border-gray-200 hover:border-blue-300 hover:shadow-md'
          }`}
        >
          <div className="flex flex-col items-center space-y-4">
            <div className="text-6xl">🐢</div>
            <h3 className="text-xl font-semibold text-gray-800">Slow and Safe</h3>
            <p className="text-gray-600 text-center">
              Conservative approach with steady growth and lower risk
            </p>
            <ul className="text-sm text-left text-gray-600 space-y-2">
              <li>• Lower Monthly Income</li>
              <li>• Slower Progress</li>
              <li>• Beginners In Markets</li>
            </ul>
          </div>
        </button>

        <button
          onClick={() => onChange('aggressive')}
          className={`p-6 rounded-xl border-2 transition-all ${
            strategy === 'aggressive'
              ? 'border-blue-600 bg-blue-50 shadow-lg scale-105'
              : 'border-gray-200 hover:border-blue-300 hover:shadow-md'
          }`}
        >
          <div className="flex flex-col items-center space-y-4">
            <div className="text-6xl">🐰</div>
            <h3 className="text-xl font-semibold text-gray-800">Swift and Aggressive</h3>
            <p className="text-gray-600 text-center">
              Faster growth potential with higher risk tolerance
            </p>
            <ul className="text-sm text-left text-gray-600 space-y-2">
              <li>• Higher Monthly Income</li>
              <li>• Higher Monthly Income</li>
              <li>• Experienced In Markets</li>
            </ul>
          </div>
        </button>
      </div>
    </div>
  );
};

export default StrategyStep;