import React from 'react';

const CapitalStep = ({ capital, monthlyInvestment, onChange }) => {
  const handleChange = (field) => (e) => {
    const rawValue = e.target.value.replace(/[^0-9.]/g, '');
    onChange(field, rawValue);
  };

  const formatValue = (val) => {
    if (!val) return '';
    return `$${Number(val).toLocaleString('en-US', { maximumFractionDigits: 2 })}`;
  };

  return (
    <div>
      <label className="block text-sm font-medium text-gray-700 mb-2">
        How much liquid capital can you start with in a non-retirement account?
      </label>
      <input
        type="text"
        value={formatValue(capital)}
        onChange={handleChange('capital')}
        className="w-full p-3 border rounded-lg mb-4"
        placeholder="$5,000.00 minimum"
      />
      <label className="block text-sm font-medium text-gray-700 mb-2">
        Avg. Monthly Additional Invested Capital (optional)
      </label>
      <input
        type="text"
        value={formatValue(monthlyInvestment)}
        onChange={handleChange('monthlyInvestment')}
        className="w-full p-3 border rounded-lg"
        placeholder="$0.00"
      />
    </div>
  );
};

export default CapitalStep;