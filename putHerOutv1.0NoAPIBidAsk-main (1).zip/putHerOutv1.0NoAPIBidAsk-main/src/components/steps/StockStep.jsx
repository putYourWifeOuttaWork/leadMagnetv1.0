import React from 'react';
import { calculateLotRequirement } from '../../utils/calculations';

const StockStep = ({ selectedStock, stockPrices, onChange, strategy, capital }) => {
  const handleStockChange = (e) => {
    const newStock = e.target.value;
    onChange(newStock);
  };

  const currentStockPrice = stockPrices[selectedStock];
  const lotRequirement = calculateLotRequirement(currentStockPrice);
  const multiplier = strategy === 'aggressive' ? 2 : 1;
  const minimumRequired = lotRequirement / multiplier;
  const canSellContract = parseFloat(capital) >= minimumRequired;
  const shortfall = minimumRequired - parseFloat(capital);

  return (
    <div className="space-y-4">
      <label className="block text-sm font-medium text-gray-700 mb-2">
        Select your wheel stock
      </label>
      <select
        value={selectedStock}
        onChange={handleStockChange}
        className="w-full p-3 border rounded-lg"
      >
        <option value="">Select a stock...</option>
        {Object.entries(stockPrices).map(([symbol, price]) => (
          <option key={symbol} value={symbol}>
            {symbol} - ${price.toLocaleString()}
          </option>
        ))}
      </select>

      {selectedStock && !canSellContract && (
        <div className="mt-4 p-4 bg-red-50 border border-red-200 rounded-lg">
          <h4 className="text-red-700 font-medium mb-2">Additional Capital Needed</h4>
          <p className="text-sm text-gray-700">
            For {selectedStock} at ${currentStockPrice.toLocaleString()}/share:
          </p>
          <ul className="mt-2 space-y-1 text-sm text-gray-600">
            <li>• Required capital: ${minimumRequired.toLocaleString()}</li>
            <li>• Your capital: ${parseFloat(capital).toLocaleString()}</li>
            <li className="text-red-600 font-medium">
              • Additional needed: ${Math.ceil(shortfall).toLocaleString()}
            </li>
          </ul>
          <p className="mt-3 text-sm text-gray-600">
            {strategy === 'aggressive' ? 
              "Even with the Hare strategy's 2x leverage, " : 
              ""
            }
            you'll need more capital to sell covered options on {selectedStock}.
          </p>
        </div>
      )}

      {selectedStock && canSellContract && (
        <div className="mt-4 p-4 bg-green-50 border border-green-200 rounded-lg">
          <h4 className="text-green-700 font-medium mb-2">Ready to Trade!</h4>
          <p className="text-sm text-gray-600">
            You have sufficient capital to sell covered options on {selectedStock}
            {strategy === 'aggressive' ? ' using 2x leverage' : ''}.
          </p>
        </div>
      )}
    </div>
  );
};

export default StockStep;