import React from 'react';

const IncomeStep = ({ value, onChange }) => {
  const handleChange = (e) => {
    const rawValue = e.target.value.replace(/[^0-9.]/g, '');
    onChange(rawValue);
  };

  const formatValue = (val) => {
    if (!val) return '';
    return `$${Number(val).toLocaleString('en-US', { maximumFractionDigits: 2 })}`;
  };

  return (
    <div>
      <label className="block text-sm font-medium text-gray-700 mb-2">
        How Much Per Month For The Wife to Quit Working?
      </label>
      <input
        type="text"
        value={formatValue(value)}
        onChange={handleChange}
        className="w-full p-3 border rounded-lg"
        placeholder="$0.00"
      />
    </div>
  );
};

export default IncomeStep;