import React from 'react';

const StepsNavigation = ({ currentStep, setStep, visitedSteps, canProceed }) => {
  const steps = [
    { label: 'Goal Income Replacement', step: 1 },
    { label: 'Choose Your Speed', step: 2 },
    { label: 'Starting Line', step: 3 },
    { label: 'Select Your Vehicle', step: 4 }
  ];

  const handleStepClick = (step) => {
    if (visitedSteps.includes(step) && (step < currentStep || canProceed(currentStep))) {
      setStep(step);
    }
  };

  return (
    <nav className="mb-12">
      <div className="max-w-3xl mx-auto bg-white rounded-2xl shadow-lg overflow-hidden">
        <div className="flex relative">
          {steps.map(({ label, step }, index) => {
            const isActive = step === currentStep;
            const isVisited = visitedSteps.includes(step);
            const isClickable = isVisited && (step < currentStep || canProceed(currentStep));
            
            return (
              <button
                key={step}
                onClick={() => handleStepClick(step)}
                className={`
                  flex-1 py-4 px-1 text-center relative z-10 transition-all
                  ${isActive ? 'text-white' : isClickable ? 'text-gray-600' : 'text-gray-400'}
                  ${isClickable ? 'cursor-pointer hover:bg-opacity-10' : 'cursor-not-allowed'}
                `}
                disabled={!isClickable}
              >
                <span className="text-sm font-medium">{label}</span>
              </button>
            );
          })}
          
          {/* Active indicator bar */}
          <div 
            className="absolute bottom-0 left-0 h-full bg-indigo-600 transition-all duration-300 ease-out"
            style={{
              width: `${100 / steps.length}%`,
              transform: `translateX(${(currentStep - 1) * 100}%)`
            }}
          />
        </div>
      </div>
    </nav>
  );
};

export default StepsNavigation;
