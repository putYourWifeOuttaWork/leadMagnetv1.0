import React, { useEffect, useRef } from 'react';
import { ResultsChart } from './ResultsChart';
import EmailCapture from './EmailCapture';
import { WorkTogether } from './WorkTogether';
import DashboardMetrics from './DashboardMetrics';

const ResultsVisualization = ({ projectionData, timeline, inputs }) => {
  const resultsRef = useRef(null);

  useEffect(() => {
    // Only scroll if we have valid projection data and the first month shows contracts > 0
    if (resultsRef.current && projectionData.length > 0 && projectionData[0].contracts > 0) {
      resultsRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [projectionData]);

  return (
    <div ref={resultsRef} className="space-y-8">
      <DashboardMetrics timeline={timeline} projectionData={projectionData} />
      
      <div className="bg-white p-6 rounded-lg shadow-lg">
        <h3 className="text-lg font-semibold mb-4">Investment Growth</h3>
        <ResultsChart projectionData={projectionData} inputs={inputs} />
      </div>

      <div className="grid grid-cols-1 gap-8">
        <EmailCapture 
          timeline={timeline}
          projectionData={projectionData}
          inputs={inputs}
        />
        <div className="bg-white p-6 rounded-lg shadow-lg">
          <WorkTogether projectionData={projectionData} />
        </div>
      </div>
    </div>
  );
};

export default ResultsVisualization;