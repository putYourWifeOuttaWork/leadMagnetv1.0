import React from 'react';

export const CustomTooltip = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    const data = payload[0].payload;
    return (
      <div className="bg-white p-4 shadow-lg rounded-lg border">
        <h4 className="font-semibold">Month {label + 1}</h4>
        <div className="grid grid-cols-2 gap-4 mt-2">
          <div>
            <p className="text-sm text-gray-600">Capital</p>
            <p className="font-medium">${data.capital.toLocaleString()}</p>
          </div>
          <div>
            <p className="text-sm text-gray-600">Net Monthly Income</p>
            <p className="font-medium">${data.netMonthlyIncome.toLocaleString()}</p>
          </div>
          <div>
            <p className="text-sm text-gray-600">Contracts</p>
            <p className="font-medium">{data.contracts}</p>
          </div>
          <div>
            <p className="text-sm text-gray-600">Monthly Reserve</p>
            <p className="font-medium">${data.monthlyReserve.toLocaleString()}</p>
          </div>
          <div>
            <p className="text-sm text-gray-600">Progress</p>
            <p className="font-medium">{data.freedomProgress.toFixed(1)}%</p>
          </div>
        </div>
      </div>
    );
  }
  return null;
};