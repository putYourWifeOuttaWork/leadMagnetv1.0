import React, { useState } from 'react';
import { ArrowRight, Trophy, CheckCircle, Loader } from 'lucide-react';

const SuccessState = () => (
  <div className="text-center space-y-6 py-8 px-4">
    <div className="text-4xl mb-4">🎉 You're In! 🎊</div>
    <Trophy className="w-16 h-16 text-pink-600 mx-auto animate-bounce" />
    <h3 className="text-2xl font-bold text-pink-600">
      Welcome to Your Freedom Journey!
    </h3>
    <div className="space-y-4 text-gray-600">
      <p>Check your email in the next 5 minutes for:</p>
      <ul className="space-y-2">
        <li className="flex items-center">
          <CheckCircle className="w-5 h-5 text-green-500 mr-2" />
          Your Personalized Freedom Plan
        </li>
        <li className="flex items-center">
          <CheckCircle className="w-5 h-5 text-green-500 mr-2" />
          Wife-Friendly Presentation Format
        </li>
        <li className="flex items-center">
          <CheckCircle className="w-5 h-5 text-green-500 mr-2" />
          Next Steps Guide
        </li>
      </ul>
    </div>
    <div className="mt-8 text-sm text-gray-500">
      <p>Tip: Share the presentation with your wife over a nice dinner 🍷</p>
    </div>
  </div>
);

const EmailCapture = ({ timeline, projectionData, inputs }) => {
  const [formData, setFormData] = useState({ email: '', name: '' });
  const [status, setStatus] = useState('idle');

  const handleSubmit = async (e) => {
    e.preventDefault();
    setStatus('submitting');
    
    try {
      await fetch('/api/subscribe', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...formData,
          calculationResults: {
            timeline,
            projectionData,
            inputs
          }
        })
      });
      setStatus('success');
    } catch (error) {
      setStatus('error');
    }
  };

  return (
    <div className="bg-gradient-to-r from-pink-50 to-purple-50 p-6 rounded-lg shadow-lg">
      {status === 'success' ? (
        <SuccessState />
      ) : (
        <form onSubmit={handleSubmit} className="space-y-4" netlify>
          <h3 className="text-xl font-bold text-pink-600">Start Your Journey to Freedom</h3>
          <div className="space-y-2">
            <input
              type="text"
              placeholder="Your Name"
              value={formData.name}
              onChange={e => setFormData({...formData, name: e.target.value})}
              className="w-full p-3 rounded-lg border focus:ring-2 focus:ring-pink-500"
              required
            />
            <input
              type="email"
              placeholder="Your Email"
              value={formData.email}
              onChange={e => setFormData({...formData, email: e.target.value})}
              className="w-full p-3 rounded-lg border focus:ring-2 focus:ring-pink-500"
              required
            />
          </div>
          <button
            type="submit"
            disabled={status === 'submitting'}
            className="w-full bg-pink-600 hover:bg-pink-700 text-white p-4 rounded-lg flex items-center justify-center disabled:opacity-50 transform transition-transform hover:scale-105"
          >
            {status === 'submitting' ? (
              <span className="flex items-center">
                <Loader className="animate-spin mr-2" />
                Processing...
              </span>
            ) : (
              <>Get Your Freedom Plan <ArrowRight className="ml-2" /></>
            )}
          </button>
          <p className="text-sm text-gray-500 text-center">
            We'll send everything you need to share with your wife to make this work...
          </p>
        </form>
      )}
    </div>
  );
};

export default EmailCapture;
