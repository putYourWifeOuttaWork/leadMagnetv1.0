import React from 'react';
import { Calculator, X, ChevronUp } from 'lucide-react';
import { WorkTogether } from './WorkTogether';

const SlideOutTracker = ({ 
  showTracker,
  setShowTracker,
  steps = [],
  currentStep,
  timeline,
  projectionData = [],
  inputs
}) => {
  const calculateProgress = () => {
    if (!projectionData.length || !inputs.wifeIncome) return 0;
    const currentIncome = projectionData[0]?.netMonthlyIncome || 0;
    const targetIncome = parseFloat(inputs.wifeIncome);
    return Math.min(Math.floor((currentIncome / targetIncome) * 100), 100);
  };

  const progress = calculateProgress();

  return (
    <>
      <div className={`fixed bottom-0 left-0 w-full h-[80vh] bg-white shadow-lg transform transition-transform duration-300 ease-in-out ${
        showTracker ? 'translate-y-0' : 'translate-y-full'
      } z-40 overflow-y-auto rounded-t-xl`}>
        <div className="p-4">
          <div className="flex justify-between items-center mb-6">
            <h3 className="text-xl font-bold flex items-center text-gray-800">
              <Calculator className="mr-2" />
              Freedom Progress
            </h3>
            <button 
              onClick={() => setShowTracker(false)}
              className="p-2 hover:bg-gray-100 rounded-full transition-colors"
              aria-label="Close tracker"
            >
              <X />
            </button>
          </div>

          <div className="space-y-3 mb-6">
            {steps.map((step, index) => (
              <div 
                key={index}
                className={`p-3 rounded-lg transition-all duration-200 ${
                  step.complete 
                    ? 'bg-green-50 border border-green-200' 
                    : index === currentStep - 1
                      ? 'bg-gray-50 border-2 border-indigo-200'
                      : 'bg-gray-50'
                }`}
              >
                <div className="flex items-center gap-2 mb-1">
                  {step.icon}
                  <p className="font-medium text-sm text-gray-800">{step.label}</p>
                </div>
                <div className={`ml-6 text-sm ${step.complete ? 'text-gray-900' : 'text-gray-500 italic'}`}>
                  {step.value || 'Ready to start your journey?'}
                </div>
              </div>
            ))}
          </div>

          {timeline && projectionData.length > 0 && (
            <>
              <div className="p-3 rounded-lg bg-green-50 border border-green-200 mb-4">
                <p className="font-medium text-sm text-gray-800">Progress to Freedom</p>
                <div className="mt-2">
                  <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-indigo-600 rounded-full transition-all duration-500"
                      style={{ width: `${progress}%` }}
                    />
                  </div>
                  <p className="text-xs mt-1 text-gray-600">
                    {progress}% of Wife's Income Replaced
                  </p>
                </div>
              </div>

              <div className="mt-4 slide-out-tracker">
                <WorkTogether projectionData={projectionData} compact={true} />
              </div>
            </>
          )}
        </div>
      </div>

      {!showTracker && projectionData.length > 0 && (
        <div className="fixed bottom-4 left-0 w-full flex justify-center z-50">
          <button
            onClick={() => setShowTracker(true)}
            className="bg-indigo-600 text-white rounded-full p-3 shadow-lg hover:bg-indigo-700 transition-all duration-300 animate-bounce"
            aria-label="Open tracker"
          >
            <ChevronUp className="w-6 h-6" />
          </button>
        </div>
      )}
    </>
  );
};

export default SlideOutTracker;