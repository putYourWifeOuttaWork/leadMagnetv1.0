import React from 'react';
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, ReferenceLine, Legend } from 'recharts';
import { CustomTooltip } from './CustomTooltip';
import { useMediaQuery } from '../hooks/useMediaQuery';

export const ResultsChart = ({ projectionData, inputs }) => {
  const isMobile = useMediaQuery('(max-width: 768px)');
  
  const maxIncome = Math.max(...projectionData.map(d => d.grossMonthlyIncome));
  const maxCapital = Math.max(...projectionData.map(d => d.capital));
  
  const roundToNiceNumber = (num) => {
    const magnitude = Math.pow(10, Math.floor(Math.log10(num)));
    return Math.ceil(num / magnitude) * magnitude;
  };

  const niceMaxIncome = roundToNiceNumber(maxIncome * 1.1);
  const niceMaxCapital = roundToNiceNumber(maxCapital * 1.1);

  const generateTicks = (max, count) => {
    const interval = max / (count - 1);
    return Array.from({ length: count }, (_, i) => Math.floor(i * interval));
  };

  const incomeTicks = generateTicks(niceMaxIncome, isMobile ? 5 : 8);
  const capitalTicks = generateTicks(niceMaxCapital, isMobile ? 5 : 8);

  return (
    <div className="h-[300px] md:h-[500px] w-full">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart 
          data={projectionData}
          margin={isMobile ? 
            { top: 20, right: 20, left: 20, bottom: 20 } : 
            { top: 50, right: 80, left: 80, bottom: 30 }
          }
        >
          <Legend 
            verticalAlign="top" 
            align="center"
            wrapperStyle={{
              paddingBottom: '20px',
              fontSize: isMobile ? '10px' : '12px'
            }}
          />
          <XAxis 
            dataKey="month"
            type="number"
            domain={[0, 35]}
            ticks={isMobile ? [0, 12, 24, 35] : [0, 6, 12, 18, 24, 30, 35]}
            label={!isMobile && { 
              value: 'Months', 
              position: 'insideBottom',
              offset: -10
            }}
            tick={{ fontSize: isMobile ? 10 : 12 }}
          />
          <YAxis 
            yAxisId="capital"
            orientation="left"
            domain={[0, niceMaxCapital]}
            ticks={capitalTicks}
            label={!isMobile && { 
              value: 'Total Capital ($)', 
              angle: -90,
              position: 'insideLeft',
              offset: -60
            }}
            tickFormatter={(value) => isMobile ? 
              `$${(value/1000)}K` : 
              `$${(value/1000).toFixed(0)}K`
            }
            tick={{ fontSize: isMobile ? 10 : 12 }}
          />
          <YAxis 
            yAxisId="income"
            orientation="right"
            domain={[0, niceMaxIncome]}
            ticks={incomeTicks}
            label={!isMobile && { 
              value: 'Monthly Income ($)', 
              angle: 90,
              position: 'insideRight',
              offset: -60
            }}
            tickFormatter={(value) => isMobile ? 
              `$${(value/1000)}K` : 
              `$${(value/1000).toFixed(0)}K`
            }
            tick={{ fontSize: isMobile ? 10 : 12 }}
          />
          <Tooltip content={<CustomTooltip />} />
          <ReferenceLine 
            y={parseFloat(inputs.wifeIncome)} 
            yAxisId="income"
            stroke="#be185d" 
            strokeDasharray="3 3"
            label={!isMobile && { 
              value: 'Freedom Line', 
              position: 'right',
              fill: '#be185d',
              offset: 10
            }}
          />
          <Line 
            yAxisId="income"
            type="stepAfter"
            dataKey="netMonthlyIncome"
            stroke="#22c55e"
            strokeWidth={2}
            name="Net Monthly Income"
            dot={false}
          />
          <Line
            yAxisId="capital"
            type="monotone"
            dataKey="capital"
            stroke="#3b82f6"
            strokeWidth={2}
            name="Total Capital"
            dot={false}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
};