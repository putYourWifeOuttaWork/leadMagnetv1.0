import React from 'react';
import { format, addDays } from 'date-fns';

const DashboardMetrics = ({ timeline, projectionData }) => {
  const calculateFreedomDate = () => {
    if (!timeline || !timeline.months) return null;
    const freedomDate = addDays(new Date(), timeline.months * 30);
    return format(freedomDate, 'MMMM d, yyyy');
  };

  const calculateDaysToFreedom = () => {
    if (!timeline || !timeline.months) return null;
    return Math.ceil(timeline.months * 30);
  };

  const calculateLongTermWealth = () => {
    if (!projectionData || projectionData.length === 0) return null;
    const lastMonth = projectionData[projectionData.length - 1];
    return {
      capital: lastMonth.capital,
      monthlyIncome: lastMonth.netMonthlyIncome || 0
    };
  };

  const freedomDate = calculateFreedomDate();
  const daysToFreedom = calculateDaysToFreedom();
  const longTermWealth = calculateLongTermWealth();

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
      <div className="bg-white p-6 rounded-lg shadow-lg">
        <h3 className="text-lg font-semibold text-gray-800 mb-2">Freedom Day</h3>
        <p className="text-2xl font-bold text-indigo-600">
          {freedomDate ? `${freedomDate}` : 'Calculating...'}
        </p>
        <p className="text-sm text-gray-600 mt-1">
          {daysToFreedom ? `Only ${daysToFreedom.toLocaleString()} days to go!` : ''}
        </p>
      </div>
      <div className="bg-white p-6 rounded-lg shadow-lg">
        <h3 className="text-lg font-semibold text-gray-800 mb-2">Long-Term Wealth Potential</h3>
        {longTermWealth ? (
          <>
            <p className="text-2xl font-bold text-indigo-600">
              ${Math.floor(longTermWealth.capital).toLocaleString()}
            </p>
            <p className="text-sm text-gray-600 mt-1">
              Generating ${Math.floor(longTermWealth.monthlyIncome).toLocaleString()}/month
            </p>
            <p className="text-xs text-gray-500 mt-2 italic">
              Patience has its rewards!
            </p>
          </>
        ) : (
          <p>Calculating potential...</p>
        )}
      </div>
    </div>
  );
};

export default DashboardMetrics;