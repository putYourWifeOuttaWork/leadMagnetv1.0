import React from 'react';
import WheelCalculator from './WheelCalculator';
import { useMediaQuery } from './hooks/useMediaQuery';

function App() {
  const isMobile = useMediaQuery('(max-width: 768px)');

  return (
    <div className={`min-h-screen bg-gray-50 ${isMobile ? 'p-4' : 'p-8'} pb-20`}>
      <div className="max-w-4xl mx-auto">
        <h1 className="text-2xl md:text-4xl font-bold text-center mb-12 text-gray-800 px-4 pt-8">
          Put Your Wife Outta Work
        </h1>
        <WheelCalculator />
      </div>
    </div>
  );
}

export default App;
